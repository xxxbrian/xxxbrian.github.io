# Chapter 8: Transcending the Mundane with Vimscript

## vim-commenter

This is a plugin we'll be working on in this chapter. You can follow along with
the book, or copy the plugin to `~/.vim/pack/plugins/start` on Linux or
`C:\Users\<username>\vimfiles\pack\plugins\start` on Windows.
