# Chapter 4: Understanding the Text

## .vimrc

See `../ch1/README.md` for copying instructions, and `../ch3/README.md` for
vim-plug download instructions.

## \*.py Files

These are Python 3 files, see `../ch1/README.md` for (slightly) more
information.

## tags File

`tags` file is produced by running `ctags -R .`, you can read more about it in "Navigating the code base with tags".
