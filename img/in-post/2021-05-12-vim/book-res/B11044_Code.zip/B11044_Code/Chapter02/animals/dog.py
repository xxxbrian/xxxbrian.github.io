"""A dog."""

import animal

class Dog(animal.Animal):

    def __init__(self):
        self.kind = 'dog'
