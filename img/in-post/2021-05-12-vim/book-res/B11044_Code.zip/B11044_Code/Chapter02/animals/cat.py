"""A cat."""

import animal

class Cat(animal.Animal):

    def __init__(self):
        self.kind = 'cat'
