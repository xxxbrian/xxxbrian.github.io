animal_noises = {
    'bark': 'dog',
    'meow': 'cat',
    'silence': 'dogfish',
}
