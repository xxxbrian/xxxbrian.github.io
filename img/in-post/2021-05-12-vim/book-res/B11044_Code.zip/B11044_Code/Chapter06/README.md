# Chapter 6: Refactoring Code with Regex and Macros

## \*.py Files

These are Python 3 files, see `../ch1/README.md` for (slightly) more
information.
